package com.pojo;

public class Item {
private String itemname;
public String getItemname() {
	return itemname;
}
public void setItemname(String itemname) {
	this.itemname = itemname;
}
public String getCategory() {
	return Category;
}
public void setCategory(String category) {
	Category = category;
}
public double getBuyingprice() {
	return buyingprice;
}
public void setBuyingprice(double buyingprice) {
	this.buyingprice = buyingprice;
}
private String Category;
private double buyingprice;
}
