package com.pojo;

public class User {
private String usrname;
private String emailid;
private String password;
private int SuperCoins;
public String getUsrname() {
	return usrname;
}
public void setUsrname(String usrname) {
	this.usrname = usrname;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getSuperCoins() {
	return SuperCoins;
}
public void setSuperCoins(int superCoins) {
	SuperCoins = superCoins;
}
}
