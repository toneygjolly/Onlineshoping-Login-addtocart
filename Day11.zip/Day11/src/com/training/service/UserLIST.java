package com.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pojo.Product;

public class UserLIST {
	private int productid;
	private String productname;
	private double sellingprice;
	private double availableQuantity;
	private List<Product>menu;
    Scanner sc;
    public UserLIST() {
    	sc=new Scanner(System.in);
    	//menu=new ArrayList<>();
    menu=new ArrayList<Product>();
    }
    public void store()
    {
    	Product e=new Product(1,"laptop",23000,2);
    	Product e1=new Product(2,"NOKIA",24000,2);
    	Product e2=new Product(3,"AAA",28000,6);
    	e.setCategory("Elctronics");
    	e1.setCategory("Mobile");
    	e2.setCategory("Laptop");
        menu.add(e);
        menu.add(e1);
        menu.add(e2);
        menu.stream().forEach(n->
        {
        	System.out.println("id="+n.getProductid());
        	System.out.println("product name="+n.getProductname());
        	System.out.println("Category="+n.getCategory());
        });
    	
    }
    
    public void searchbyId() {
    	System.out.println("Enter the product id");
    	int id=sc.nextInt();
    	boolean found=false;
    	found=menu.stream().anyMatch(i->i.getProductid()==id);
    			if(!found)
    			
    	{
    		System.out.println("found");
    	}
    			else{
    	    		System.out.println("not found");

    			
    }	
    }
    public void productbyName() {
    	System.out.println("Enter the name");
    	String name=sc.next();
    	boolean found=false;
    	found=menu.parallelStream().anyMatch(i->i.getProductname()==name);
    	if(!found)
    	{
    		System.out.println("Name is found");
    	}
    	else {
    		System.out.println("Name is Not found");

    	}
    }
    public void CategoryName() {
    	
    	
        	System.out.println("Enter the Category");
        	String category=sc.next();
        	boolean found=false;
        	found=menu.parallelStream().anyMatch(i->i.getProductname()==category);
        	if(!found)
        	{
        		menu.stream().forEach(n->
                {
				System.out.println("Name is found="+n.getProductname());
                });
        	}
        	
        }
    	
    
    	
    	
    
    public static void main(String []args) {
    	AdminList al=new AdminList();
    }
}


